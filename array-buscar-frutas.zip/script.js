document.addEventListener("DOMContentLoaded", function() {
    const frutas = [];
    const precos = [];
    const tabelaFrutas = document.getElementById('tabela-frutas');

    document.getElementById("inserir").addEventListener("click", inserirFruta);
    document.getElementById("buscar").addEventListener("click", buscarFruta);
    document.getElementById("listar").addEventListener("click", listarFrutas);

    function inserirFruta() {
        const fruta = document.getElementById('fruta').value.trim();
        const preco = parseFloat(document.getElementById('preco').value);

        if (fruta !== '' && !isNaN(preco) && preco >= 0) {
            frutas.push(fruta);
            precos.push(preco);
            document.getElementById('fruta').value = '';
            document.getElementById('preco').value = '';
            document.getElementById('resultado').textContent = `A fruta "${fruta}" foi inserida com preço R$${preco.toFixed(2)}.`;
        } else {
            document.getElementById('resultado').textContent = 'Por favor, insira um nome de fruta válido e um preço válido.';
        }
    }

    function buscarFruta() {
        const fruta = document.getElementById('fruta').value.trim();
        if (fruta !== '') {
            const index = frutas.indexOf(fruta);
            if (index !== -1) {
                document.getElementById('resultado').textContent = `A fruta "${fruta}" foi encontrada no array com preço R$${precos[index].toFixed(2)}.`;
            } else {
                document.getElementById('resultado').textContent = `A fruta "${fruta}" não foi encontrada no array.`;
            }
        } else {
            document.getElementById('resultado').textContent = 'Por favor, insira um nome de fruta válido.';
        }
    }

    function listarFrutas() {
        // Limpar a tabela
        const corpoTabela = document.getElementById('corpo-tabela');
        corpoTabela.innerHTML = '';

        // Adicionar frutas e preços à tabela
        for (let i = 0; i < frutas.length; i++) {
            const linha = document.createElement('tr');
            const celulaFruta = document.createElement('td');
            const celulaPreco = document.createElement('td');

            celulaFruta.textContent = frutas[i];
            celulaPreco.textContent = `R$${precos[i].toFixed(2)}`;

            linha.appendChild(celulaFruta);
            linha.appendChild(celulaPreco);
            corpoTabela.appendChild(linha);
        }

        // Mostrar a tabela
        tabelaFrutas.style.display = 'block';
    }
});

